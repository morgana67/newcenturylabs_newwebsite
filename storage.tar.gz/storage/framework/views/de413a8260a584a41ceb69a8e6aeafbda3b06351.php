<?php $__env->startSection('content'); ?>
    <section class="box-area text-center  pt20 pb50">
        <section class="inr-bnr-blank">
            <div class="container">
                <div class="hed"><h2>LOGIN</h2></div>
            </div>
        </section>
        <?php if(session()->has('success')): ?>
            <div class="mt-2 alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo session('success'); ?>

            </div>
        <?php endif; ?>
        <section class="inr-intro-area ">
            <div class="container">
                <div class="fom col-sm-6 fom-shad pt20">
                    <div class="col-md-12">
                        <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <form method="POST" class="form" action="<?php echo e(!empty(request()->get('redirect')) ? route('login',['redirect' => request()->get('redirect')]) : route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>" required/>
                        </div>

                        <div class="form-group">
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password"
                                   required/>
                        </div>
                        <div class="form-group mb10 overload">
                            <div class="checkbox-area pul-lft">
                                <input type="checkbox" class="checkbox" name="remember"><label>Remember Me</label>
                            </div>

                        </div>
                        <div class="form-group">
                            <button ype="submit" class="form-control w100 btn-primary">LOGIN</button>
                        </div>
                    </form>
                    <a href="<?php echo e(route('password.request')); ?>" class="link pul-lft">
                        <i class="fa fa-support"></i>Lost your password?
                    </a>
                </div>
                <div class="cont text-center col-sm-6 pl50 pr50">
                    <h2>REGISTER</h2>
                    <p>Registering allows you to order tests. Just fill in the fields and we’ll get you ready to go in
                        no time. We will only ask you for information that allows us to prepare your lab order.</p>
                    <div class="lnk-btn "><a href="<?php echo e(route('register')); ?>">REGISTER</a></div>
                </div>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/auth/login.blade.php ENDPATH**/ ?>