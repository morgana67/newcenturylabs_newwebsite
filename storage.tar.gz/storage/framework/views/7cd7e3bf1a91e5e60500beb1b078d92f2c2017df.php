<?php $__env->startSection('title'); ?><?php echo e($product->name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e(strip_tags($product->description)); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($product->keywords); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="bnr-area page-bnr-area bg-full bg-cntr valigner"
             style="background-image:url(<?php echo e(asset('/front/images/testmenu2.jpg')); ?>);">
        <div class="container">
            <div class="bnr__cont valign white text-center col-sm-12 text-uppercase anime-flipInX">
                <h2></h2>
                <h3><?php echo e($product->name); ?></h3>
            </div>
        </div>
    </section>
    <section class="description-area">
        <div class="container">
            <div class="description-box col-sm-6">
                <div class="description__inr">
                    <div class="description__cont">
                        <h3>Description</h3>
                        <?php echo $product->description; ?>

                    </div>
                </div>
            </div>
            <div class="description-box col-sm-6">
                <div class="description__inr">

                    <div class="circle__cont text-center">
                        <div>
                            <h3><?php echo e($product->name); ?></h3>
                            <?php
                              if($product->sale_price != null){
                                    $price = $product->sale_price;
                                }else{
                                    $price = $product->price;
                                }
                            ?>
                            <?php if($product->sale_price != null): ?>
                                <h2><sup><?php echo e(setting('site.currency')); ?></sup><?php echo e(format_price($price)); ?></h2>
                                <strong>Average competitors price</strong>
                                <h4><sup><?php echo e(setting('site.currency')); ?></sup><?php echo e(format_price($product->price)); ?></h4>
                            <?php else: ?>
                                <h2><sup><?php echo e(setting('site.currency')); ?></sup><?php echo e($price); ?></h2>
                                <strong>Average competitors price</strong>
                            <?php endif; ?>
                            <strong>Pricing based on average direct to consumer pricing.</strong>
                            <div class="checkout-area">
                                <form method="POST" action="<?php echo e(route('cart.add')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="1" name="quantity" id="quantity"/>
                                    <input type="hidden" name="price" id="price" value="<?php echo e($price); ?>"/>
                                    <input type="hidden" name="product_id" id="product_id" value="<?php echo e($product->id); ?>"/>
                                    <input type="hidden" name="name" id="name" value="<?php echo e($product->name); ?>"/>
                                    <input type="hidden" name="slug" id="slug" value="<?php echo e($product->slug); ?>"/>
                                    <button id="btn_add_to_cart" class="out-btn btn btn-default">CHECKOUT</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="fasting-area">
        <div class="container">
            <div class="fasting-cont fasting-list clrlist listview">
                <?php echo $product->requirement; ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/product-detail.blade.php ENDPATH**/ ?>