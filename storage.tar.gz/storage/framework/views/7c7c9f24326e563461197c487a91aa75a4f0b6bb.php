<ul class="nav navbar-nav navbar-main">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $isActive = null;
            if((strpos(url()->current(), url($menu_item->link())) !== false) && $menu_item->link() != ''){
                $isActive = 'active';
            }
            if(!$menu_item->children->isEmpty()){
                 foreach($menu_item->children as $children){
                      if((strpos(url()->current(), url($children->link())) !== false)){
                            $isActive = 'active';
                        }
                 }
            }
        ?>
        <li class="<?php echo e($isActive); ?>">
            <a  <?php if(!$menu_item->children->isEmpty()): ?>
                 href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                 aria-haspopup="true" aria-expanded="false"
                <?php else: ?>
                 href="<?php echo e($menu_item->link()); ?>"
                <?php endif; ?>
            ><?php echo e($menu_item->title); ?>

                <?php if(!$menu_item->children->isEmpty()): ?>
                    <span class="caret"></span>
                <?php endif; ?>
            </a>
            <?php if(!$menu_item->children->isEmpty()): ?>
                <ul class="dropdown-menu">
                    <?php $__currentLoopData = $menu_item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($children->link()); ?>"><?php echo e($children->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(!is_customer()): ?>
        <li class="login-link <?php echo e($isActive); ?>"><a href="<?php echo e(route('login')); ?>">Login</a></li>
    <?php else: ?>
        <li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
               aria-expanded="false">My Account<span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li><a href="<?php echo e(route('myOrder')); ?>" class="pagelinkcolor">My Orders</a></li>
                <li><a href="<?php echo e(route('profile.changePassword')); ?>" class="pagelinkcolor">Change Password</a></li>
                <li><a href="<?php echo e(route('profile.profile')); ?>" class="pagelinkcolor">Profile</a></li>
                <li><a href="!#" class="pagelinkcolor" id="logout">Log Out</a></li>
            </ul>
        </li>
    <?php endif; ?>

    <li class="cart-item">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
           aria-haspopup="true" aria-expanded="false"><i
                class="fa fa-shopping-cart fa-2"></i> <span>Cart<sup
                    class="badge"></sup></span> </a>

        <ul class="dropdown-menu">
            <?php if(user() != null && Cart::count() == 0 && user()->role_id == 2): ?>
                 <li><a href="javascript:void(0);" class="pagelinkcolor">No items</a></li>
            <?php else: ?>
                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('product_detail',['slug' => $product->id])); ?>" class="pagelinkcolor"><?php echo e($product->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="p10 col-sm-12 active d-flex justify-content-flex-end">
                            <a class="btn btn-warning" href="<?php echo e(route('cart.view')); ?>"><i class="fa fa-arrow-right"></i> View Cart</a>
                            <a class="btn btn-primary" href="<?php echo e(route('cart.checkout')); ?>"><i class="fa fa-shopping-cart"></i> Check out</a>
                        </div>
                    </li>
            <?php endif; ?>

        </ul>
    </li>
</ul>

<?php /**PATH /home/forge/newcenturylabs.com/resources/views/menu_header.blade.php ENDPATH**/ ?>