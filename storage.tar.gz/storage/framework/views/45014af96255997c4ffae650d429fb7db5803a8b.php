<?php $__env->startSection('content'); ?>
    <section class="bnr-area page-bnr-area bg-full bg-cntr valigner"
             style="background-image:url(<?php echo e(asset('front/images/bnr-signup.jpg')); ?>);margin-bottom: 50px">
        <div class="container">
            <div class="bnr__cont valign white text-center col-sm-12 text-uppercase anime-flipInX">
                <h2>Reset Password</h2>
            </div>
        </div>
    </section>

    <form method="POST" action="<?php echo e(route('resetPassword')); ?>" class="form pt-3" name="register" style="margin-bottom: 50px">
        <?php echo csrf_field(); ?>
        <section class="billing-area ">
            <div class="container">
                <div class="fom col-sm-6 fom-shad pt20 p0 pul-cntr">
                    <div class="col-md-12">
                        <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group col-sm-12">
                        <input placeholder="Email *" class="form-control" required="required" name="email" type="email"
                               value="<?php echo e(old('email')); ?>" >
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-sm-12">
                            <button type="submit" class="form-control w100 btn-primary">RESET PASSWORD</button>
                    </div>
                </div>
            </div>
        </section>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>