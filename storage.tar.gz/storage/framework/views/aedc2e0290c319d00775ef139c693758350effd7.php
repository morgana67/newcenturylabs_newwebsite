<?php $__env->startSection('title'); ?><?php echo e($page->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($page->meta_description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($page->meta_keywords); ?><?php $__env->stopSection(); ?>
<?php
    $body = json_decode($page->body);
?>
<?php $__env->startSection('content'); ?>
    <section class="page-bnr-area bg-full bg-cntr valigner" style="background-image:url('<?php echo e(image($body->banner ?? null)); ?>');">
        <div class="container">
            <div class="bnr__cont valign white text-center col-sm-12 text-uppercase anime-flipInX">
                <h2><?php echo e(strtoupper($page->title)); ?></h2>

                <h3><?php echo $body->desc_banner ?? null; ?></h3>
            </div>
        </div>
    </section>

    <section class="about-area pt50 pb50">
        <div class="container">
            <div class="cont">
               <?php echo $body->desc_section1 ?? null; ?>

            </div>

            <div class="clearfix">&nbsp;</div>

            <div class="about-box col-sm-4 anime-left">
                <div class="about__icon"><img alt="" src="<?php echo e(image($body->img_icon_1_section1 ?? null)); ?>"/></div>

                <div class="about__cont">
                    <h3><?php echo $body->title_icon_1_section1 ?? null; ?></h3>

                    <p><?php echo $body->desc_icon_1_section1 ?? null; ?></p>
                </div>
            </div>

            <div class="about-box col-sm-4 anime-in">
                <div class="about__icon"><img alt="" src="<?php echo e(image($body->img_icon_2_section1 ?? null)); ?>"/></div>

                <div class="about__cont">
                    <h3><?php echo $body->title_icon_2_section1 ?? null; ?></h3>

                    <p><?php echo $body->desc_icon_2_section1 ?? null; ?></p>
                </div>
            </div>

            <div class="about-box col-sm-4 anime-right">
                <div class="about__icon"><img alt="" src="<?php echo e(image($body->img_icon_3_section1 ?? null)); ?>"/></div>

                <div class="about__cont">
                    <h3><?php echo $body->title_icon_3_section1 ?? null; ?></h3>

                    <p><?php echo $body->desc_icon_3_section1 ?? null; ?></p>
                </div>
            </div>
        </div>
    </section>

    <section class="testlab-area text-center bg-full white p100 valigner"
             style="background-image:url('<?php echo e(image($body->image_section2 ?? null)); ?>');">
        <div class="container">
            <div class="valign ">
                <h4><?php echo $body->desc_section2 ?? null; ?></h4>

                <div class="inline-btns mt40">
                    <div class="lnk-btn inline-block def-btn hover"><a href="<?php echo e($body->link_section2 ?? null); ?>">View Tests</a></div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/about-us.blade.php ENDPATH**/ ?>