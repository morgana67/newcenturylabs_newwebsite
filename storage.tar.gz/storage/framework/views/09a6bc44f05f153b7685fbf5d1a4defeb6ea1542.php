<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>

<?php if($exception): ?>
    <?php $__env->startSection('message', $exception->getMessage()); ?>
<?php else: ?>
    <?php $__env->startSection('message', __('Not Found')); ?>
<?php endif; ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/errors/404.blade.php ENDPATH**/ ?>