<?php $__env->startSection('content'); ?>
    <section class="bnr-area page-bnr-area bg-full bg-cntr valigner"
             style="background-image:url('front/images/bnr-signup.jpg');">
        <div class="container">
            <div class="bnr__cont valign white text-center col-sm-12 text-uppercase anime-flipInX">
                <h2>SIGN UP</h2>
                <h4></h4>
            </div>
        </div>
    </section>

    <form method="POST" action="<?php echo e(route('postRegister')); ?>" class="form" name="register">
        <?php echo csrf_field(); ?>
        <section class="billing-area ">
            <div class="container">

                <div class="fom fom-shad pt20 col-sm-9 p0 pul-cntr">
                    <div class="col-md-12">
                        <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="form-group col-sm-6">
                        <input placeholder="First Name *" class="form-control" required="required" name="firstName"
                               type="text" value="<?php echo e(old('firstName')); ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <input placeholder="Last Name *" class="form-control" required="required" name="lastName"
                               type="text" maxlength="191" value="<?php echo e(old('lastName')); ?>">

                    </div>

                    <div class="form-group col-sm-12">
                        <input placeholder="Email *" class="form-control" required="required" name="email" type="email"
                               value="<?php echo e(old('email')); ?>" >

                    </div>

                    <div class="form-group col-sm-12">
                        <input placeholder="Password *" class="form-control"
                               pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required="required" name="password"
                               type="password" value="">

                    </div>

                    <div class="form-group col-sm-12">
                        <input data-match-error="Whoops, these don&#039;t match" placeholder="Confirm Password *"
                               data-match="#password" class="form-control" required="required"
                               name="password_confirmation" type="password" value="">

                    </div>
                    <div class="form-group col-sm-12">
                        <div class="alert alert-info">
                            Your password must contain minimum 8 characters, at least 1 uppercase alphabet, 1 lowercase
                            alphabet, 1 number and 1 special character.
                        </div>
                    </div>

                    <div class="form-group col-sm-6 clrhm">
                        <h5><label for="gender">Gender *</label></h5>
                        <div class="inline-form">
                            <input <?php echo e(old('gender') == 'm' || empty(old('gender')) ? 'checked' : ''); ?> name="gender" type="radio" value="m" id="gender">
                            <label for="Male">Male</label>
                            <input <?php echo e(old('gender') == 'f' ? 'checked' : ''); ?> name="gender" type="radio" value="f" id="gender">
                            <label for="Female">Female</label>
                        </div>
                    </div>

                    <div class="form-group col-sm-12 clrhm">
                        <label><label for="gender">Date of birth*</label></label>
                        <br>
                        <div class="form-group col-sm-2 pl0">
                            <select class="form-control" required="required" name="date">
                                <?php for($i = 1;$i <= 31; $i++): ?>
                                    <option  <?php echo e(old('date') == $i ? 'selected' : ''); ?> value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="form-group col-sm-3">
                            <select class="form-control" required="required" name="month">
                                <option <?php echo e(old('month') == 1 ? 'selected' : ''); ?> value="1">January</option>
                                <option <?php echo e(old('month') == 2 ? 'selected' : ''); ?> value="2">February</option>
                                <option <?php echo e(old('month') == 3 ? 'selected' : ''); ?> value="3">March</option>
                                <option <?php echo e(old('month') == 4 ? 'selected' : ''); ?> value="4">April</option>
                                <option <?php echo e(old('month') == 5 ? 'selected' : ''); ?> value="5">May</option>
                                <option <?php echo e(old('month') == 6 ? 'selected' : ''); ?> value="6">June</option>
                                <option <?php echo e(old('month') == 7 ? 'selected' : ''); ?> value="7">July</option>
                                <option <?php echo e(old('month') == 8 ? 'selected' : ''); ?> value="8">August</option>
                                <option <?php echo e(old('month') == 9 ? 'selected' : ''); ?> value="9">September</option>
                                <option <?php echo e(old('month') == 10 ? 'selected' : ''); ?> value="10">October</option>
                                <option <?php echo e(old('month') == 11 ? 'selected' : ''); ?> value="11">November</option>
                                <option <?php echo e(old('month') == 12 ? 'selected' : ''); ?> value="12">December</option>
                            </select>
                        </div>
                        <div class="form-group col-sm-2">
                            <select class="form-control" required="required" name="year">
                                <?php for($i = 2016;$i >= 1930; $i--): ?>
                                    <option <?php echo e(old('year') == $i ? 'selected' : ''); ?> value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                    </div>

                    <div class="form-group col-sm-12">
                        <input placeholder="Country United States (US)" class="form-control" readonly="readonly"
                               required="required" name="country" type="text">
                    </div>

                    <div class="form-group col-sm-6">
                        <select name="state" id="state" required class="form-control">
                            <option>State *</option>
                            <?php $__currentLoopData = \App\Models\State::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('state') == $state->code ? 'selected' : ''); ?> value="<?php echo e($state->code); ?>"><?php echo e($state->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group col-sm-6">
                        <input placeholder="City *" class="form-control" required="required" name="city" type="text" value="<?php echo e(old('city')); ?>">
                    </div>
                    <div class="form-group col-sm-12">
                        <input placeholder="Address *" class="form-control" required="required" name="address"
                               type="text" value="<?php echo e(old('address')); ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <input placeholder="Postal Code / Zipcode *" class="form-control" required="required" name="zip"
                               type="text" value="<?php echo e(old('zip')); ?>">
                    </div>

                    <div class="form-group col-sm-6">
                        <input placeholder="Phone *" class="form-control" required="required" name="phone" type="text"
                               value="<?php echo e(old('phone')); ?>" >
                    </div>
                    <div class="form-group col-sm-6">

                    </div>
                    <div class="form-group col-sm-6 text-right">
                        <button type="submit" class="btn btn-flat btn-primary ">SIGNUP</button>
                    </div>
                    <div class="form-group col-sm-12">
                        <small>We do not support orders from the following states:
                            <strong>NY, NJ RI, MD, HI</strong></small>
                    </div>
                    <input name="role_id" type="hidden" value="2">
                </div>
            </div>
        </section>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/auth/register.blade.php ENDPATH**/ ?>