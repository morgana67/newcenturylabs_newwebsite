<?php $__env->startSection('title'); ?><?php echo e($faq->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($faq->meta_description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($faq->meta_keywords); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $faqBody = json_decode($faq->body);
    ?>
    <section class="inr-intro-area pt100 pb40">
        <div class="container">
            <div class="hed text-center">
                <h2><?php echo e(strtoupper($faq->title)); ?></h2>
            </div>

            <div calss="cont">
                <?php echo $faqBody->content_page; ?>


                <div class="panel-group accordion-arr" id="accordion">
                    <div class="col-sm-6 p0">
                        <?php if(!empty($faqBody->detail)): ?>
                            <?php $i = 0; ?>
                            <?php $__currentLoopData = $faqBody->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_left): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse"
                                                                   href="#collapse<?php echo e($i); ?>"><?php echo $detail_left->left_title; ?></a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse collapse " id="collapse<?php echo e($i); ?>">
                                        <div class="panel-body"><?php echo $detail_left->left_content; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6 p0">
                        <?php if(!empty($faqBody->detail)): ?>
                            <?php $i = 100; ?>
                            <?php $__currentLoopData = $faqBody->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_right): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse"
                                                                   href="#collapse<?php echo e($i); ?>"><?php echo $detail_right->right_title; ?></a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse collapse " id="collapse<?php echo e($i); ?>">
                                        <div class="panel-body"><?php echo $detail_right->right_content; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/faq.blade.php ENDPATH**/ ?>