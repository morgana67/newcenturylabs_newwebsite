<?php $__env->startSection('title'); ?><?php echo e(!empty($post->seo_title) ? $post->seo_title : $post->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($post->meta_description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($post->meta_keywords); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="blog-post-area">
        <div class="container">
            <div class="bpost__heading text-center col-sm-12 pt50">
                <h2><?php echo e($post->title); ?></h2>
            </div>
        </div>
    </section>
    <section class="blog-dtl-area">
        <div class="container">
            <div class="dtl__main col-sm-12">
                <div class="dtl__img">
                    <img src="<?php echo e(image($post->image)); ?>" alt="<?php echo e($post->title); ?>">
                </div>
                <div class="dtl__postDay">
                    <ul>
                        <li><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date("h:m a", strtotime($post->created_at))); ?>, </li>
                        <li><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo e(date("F d, Y", strtotime($post->created_at))); ?> </li>
                    </ul>
                </div>
                <div class="dtl__content">
                    <div class="dtl__content">
                        <?php echo $post->body; ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="blog-posted-area pt50 pb50" >
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $similarPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similarPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="posted-box col-sm-4">
                    <div class="posted__img">
                        <img src="<?php echo e(image($similarPost->image,'-medium')); ?>" alt="<?php echo e($similarPost->title); ?>" />
                        <div class="posted__hover">
                            <a href="<?php echo e(route('post_detail',['slug' => $similarPost->slug])); ?>"><i class="fa fa-link" aria-hidden="true"></i></a>
                        </div>
                    </div>
                    <div class="posted__cont">
                        <div class="dtl__postDay">
                            <ul>
                                <li><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date("h:m a", strtotime($similarPost->created_at))); ?> </li>
                                <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e(date("F d, Y", strtotime($similarPost->created_at))); ?> </li>
                            </ul>
                            <h3><a href="<?php echo e(route('post_detail',['slug' => $similarPost->slug])); ?>"><?php echo e($similarPost->title); ?></a></h3>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/blog-detail.blade.php ENDPATH**/ ?>