<?php $__env->startSection('title'); ?><?php echo e($page->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($page->meta_description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($page->meta_keywords); ?><?php $__env->stopSection(); ?>
<?php
    $body = json_decode($page->body);
?>
<?php $__env->startSection('content'); ?>
    <section class="page-bnr-area bg-full valigner" style="background-image:url('<?php echo e(image($body->banner ?? null)); ?>');">
        <div class="container">
            <div class="bnr__cont valign white text-center col-sm-12 anime-flipInX">
                <h2><?php echo $body->title_banner ?? null; ?></h2>

                <p><?php echo $body->desc_banner  ?? null; ?></p>
            </div>
        </div>
    </section>

    <section class="how-step-area pt50 pb50">
        <div class="container">
            <?php if(!empty($body->detail)): ?>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $body->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i % 2 != 0): ?>
                        <div class="step__cont col-sm-5">
                            <div class="step__img"><img alt="" src="<?php echo e(image($detail->image_step ?? null)); ?>"/></div>
                        </div>

                        <div class="step__cont col-sm-7 valigner anime-left">
                            <div class="step_list clrlist listview valign">
                                <h3><?php echo $detail->title_step ?? null; ?></h3>
                                <ul>
                                    <li> <?php echo $detail->content_step ?? null; ?></li>
                                </ul>
                            </div>
                        </div>
                        <div class="clearfix">&nbsp;</div>
                    <?php else: ?>
                        <div class="step__cont col-sm-7 valigner anime-left">
                            <div class="step_list clrlist listview valign">
                                <h3><?php echo $detail->title_step ?? null; ?></h3>
                                <ul>
                                    <li> <?php echo $detail->content_step ?? null; ?></li>
                                </ul>
                            </div>
                        </div>

                        <div class="step__cont col-sm-5">
                            <div class="step__img"><img alt="" src="<?php echo e(image($detail->image_step ?? null)); ?>"/></div>
                        </div>

                        <div class="clearfix">&nbsp;</div>
                    <?php endif; ?>
                    <?php $i++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/how-to-order.blade.php ENDPATH**/ ?>