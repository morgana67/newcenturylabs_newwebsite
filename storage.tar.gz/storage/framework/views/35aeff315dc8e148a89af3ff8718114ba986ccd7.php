<?php $__env->startSection('title'); ?><?php echo e('Test By Disease'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e('Test By Disease'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e('Test By Disease'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="bnr-area page-bnr-area bg-full bg-cntr valigner" style="background-image:url('<?php echo e(asset('front/images/testmenu2.jpg')); ?>');">
        <div class="container">
            <div class="bnr__cont valign white text-center col-sm-12 text-uppercase anime-flipInX">
                <h2>Disease Category</h2>
                <h4>INFORMATION ABOUT “YOU” WHEN YOU WANT IT!</h4>
            </div>
        </div>
    </section>

    <section class="test-bd-area pt50 pb50" >
        <div class="container">
            <p>We all have health concerns, and sometimes, linking symptoms with blood tests can be challenging.  We’re making it easier to help you search and group blood tests by specific health concerns with our new blood tests by disease search.</p>
            <div class="test-menu-area table-responsive0">

                <h3>Health Concerns</h3>

                <style>
                    td[colspan] {
                        font-size: 28px;
                    }
                </style>

                <table id="example" class="table table-area0 table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th class="col-sm-8">Disease category</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>Disease category</th>
                    </tr>
                    </tfoot>
                    <tbody>


                    <?php $__currentLoopData = $diseaseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('testlistbydisease',['id' => $element->id])); ?>"><?php echo e($element->name); ?></a>
                            <a class="btn btn-view pul-rgt" href="<?php echo e(route('testlistbydisease',['id' => $element->id])); ?>">View</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/testbydisease.blade.php ENDPATH**/ ?>