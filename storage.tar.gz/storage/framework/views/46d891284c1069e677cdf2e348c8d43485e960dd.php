<?php $__env->startSection('title'); ?><?php echo e($page->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($page->meta_description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($page->meta_keywords); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="inr-intro-area pt100 ">
        <div class="container">
            <div class="page__title text-center mb30 text-uppercase">
                <h2><?php echo e(strtoupper($page->title)); ?></h2>
            </div>

        </div>
    </section>

    <section class="cont-area  pt30 pb30 big">
        <div class="container">
            <?php echo $page->body; ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/privacy.blade.php ENDPATH**/ ?>