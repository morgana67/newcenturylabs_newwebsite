<?php
    use Carbon\Carbon;
?>
<?php $__env->startSection('title'); ?><?php echo e(!isset($category) ? 'Blog' : $category->name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e(!isset($category) ? 'Blog' : $category->name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e(!isset($category) ? 'Blog' : $category->name); ?><?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="bnr-area page-bnr-area bg-full bg-cntr valigner"
             style="background-image:url('/front/images/bnr-blog.jpg');">
        <div class="container">
            <div class="bnr__cont valign white text-center col-sm-12 text-uppercase anime-flipInX">
                <h2>Blog</h2>
            </div>
        </div>
    </section>
    <section class="blogs-cont-area pt30">
        <div class="container">
            <div class="blogs__featured col-sm-8">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $date = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s',$post->created_at)?>
                    <?php if( ($key+1) % 3 != 0): ?>
                        <div class="blogs__articles col-sm-12">
                            <div class="blogs__img col-sm-4">
                                <div class="blogs__imginner">
                                    <img style="width: 100%;" src="<?php echo e(image($post->image,'-cropped')); ?>"
                                         alt="<?php echo e($post->title); ?>">
                                </div>
                            </div>
                            <div class="blogs__cont col-sm-8">
                                <h3><a href="<?php echo e(route('post_detail',['slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a></h3>
                                <div class="dtl__postDay">
                                    <ul>
                                        <li><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($date->format('g:i A')); ?>

                                        </li>
                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo e($date->format('F d, Y')); ?>

                                        </li>
                                    </ul>
                                </div>
                                <p><?php echo e($post->excerpt); ?></p>
                                <div class="dtl__postDayHover">
                                    <ul class="dtl__hoverList">
                                        <li><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($date->format('g:i A')); ?>

                                        </li>
                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo e($date->format('F d, Y')); ?>

                                        </li>
                                    </ul>
                                </div>
                                <div class="blogs__readMore">
                                    <a href="<?php echo e(route('post_detail',['slug' => $post->slug])); ?>">Read More >></a>
                                </div>
                                
                                
                                
                                
                                
                                
                                
                                
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    <?php else: ?>
                        <div class="blogs__articles col-sm-12 post__featured">
                            <div class="blogs__img col-sm-4">
                                <div class="blogs__imginner">
                                    <img src="<?php echo e(image($post->image)); ?>" width="100%" alt="<?php echo e($post->title); ?>">
                                </div>
                            </div>
                            <div class="blogs__cont col-sm-8">
                                <h3><a href="<?php echo e(route('post_detail',['slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a></h3>
                                <div class="dtl__postDay">
                                    <ul>
                                        <li><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($date->format('g:i A')); ?>

                                        </li>
                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo e($date->format('F d, Y')); ?>

                                        </li>
                                    </ul>
                                </div>
                                <p><?php echo e($post->excerpt); ?></p>
                                <div class="blogs__readMore">
                                    <a href="<?php echo e(route('post_detail',['slug' => $post->slug])); ?>">Read More >></a>
                                </div>
                                <!--
                                <div class="blogs__commLike">
                                    <div class="blogs__like">
                                        <i class="fa fa-heart-o" aria-hidden="true"></i>105
                                    </div>
                                    <div class="blogs__comment">
                                        <i class="fa fa-comments-o" aria-hidden="true"></i>35
                                    </div>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-sm-4 blogs__sidebar">
                <div class="sidebar__srch">
                    <form action="">
                        <input type="text" name="q" value="<?php echo e(request()->get('q')); ?>" class="form-control" placeholder="Search for...">
                        <i class="fa fa-search" aria-hidden="true"></i>
                    </form>
                </div>
                <div class="siderbar__category">
                    <h3>Categories</h3>
                    <ul>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('blog',['slug' => $category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="sidebar__posts mb-4" style="margin-bottom: 40px">
                    <h3>Latest Posts</h3>
                    <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sidebar__postLinks">
                            <div class="sidebar__imgs">
                                <img src="<?php echo e(image($latestPost->image,'-cropped')); ?>"
                                     alt="<?php echo e($latestPost->title); ?>">
                            </div>
                            <div class="sidebar__latest">
                                <h5><a href="<?php echo e(route('post_detail',['slug' => $latestPost->slug])); ?>"><?php echo e($latestPost->title); ?></a></h5>
                                <p style="color: #595959"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo e($latestPost->created_at->format('M. jS, Y')); ?>.</p>
                                <a style="color: #428bca" href="<?php echo e(route('post_detail',['slug' => $latestPost->slug])); ?>">Read More >> </a>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/blog.blade.php ENDPATH**/ ?>