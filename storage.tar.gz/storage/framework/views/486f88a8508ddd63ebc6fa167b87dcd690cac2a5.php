<?php
    use Jenssegers\Agent\Agent as Agent;
    $Agent = new Agent();
    $body = json_decode($page->body);
?>

<?php $__env->startSection('title'); ?><?php echo e($page->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($page->meta_description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($page->meta_keywords); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="slider-area no-ctrl fadeft">
        <div class="carousel slide" data-interval="false" data-ride="carousel" id="carousel-example-generic">
            <ol class="carousel-indicators hidden">
                <li class="active" data-slide-to="0" data-target="#carousel-example-generic">&nbsp;</li>
                <li data-slide-to="1" data-target="#carousel-example-generic">&nbsp;</li>
                <li data-slide-to="2" data-target="#carousel-example-generic">&nbsp;</li>
            </ol>
            <!-- Wrapper for slides -->

            <div class="carousel-inner">
                <div class="item active">
                    <img alt="..." src="<?php echo e(image($body->banner)); ?>"/>
                    <div class="container posrel">
                        <div class="caro-caps anime-flipInX">
                            <h1><?php echo $body->title_banner ?? null; ?></h1>

                            <p><?php echo $body->desc_banner ?? null; ?></p>
                            <?php if(!is_customer()): ?>
                                <div class="lnk-btn inline-block more-btn"><a href="<?php echo e(route('register')); ?>">Sign Up With Us</a></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="box-area text-center pt20 pb50">
        <div class="hed">
            <h2><?php echo $body->title_section1 ?? null; ?></h2>

            <p><?php echo $body->desc_section1 ?? null; ?></p>
        </div>
    </section>
    <section class="slider-area no-ctrl fadeft  pb50">
        <div class="box-area text-center col-md-4">
            <div class="box col-sm-12 anime-left ">
                <div class="box__img"><img alt="" src="<?php echo e(image($body->img_icon_1_section1 ?? null)); ?>"/></div>

                <div class="box__cont ">
                    <h4><?php echo $body->title_icon_1_section1 ?? null; ?></h4>

                    <p><?php echo $body->desc_icon_1_section1 ?? null; ?></p>

                    <div class="lnk-btn more-btn"><a href="#">LEARN MORE</a></div>
                </div>
            </div>

            <div class="box col-sm-12 anime-in">
                <div class="box__img"><img alt="" src="<?php echo e(image($body->img_icon_2_section1 ?? null)); ?>"/></div>

                <div class="box__cont">
                    <h4><?php echo $body->title_icon_2_section1 ?? null; ?></h4>

                    <p><?php echo $body->title_icon_2_section1 ?? null; ?></p>

                    <div class="lnk-btn more-btn"><a href="#">LEARN MORE</a></div>
                </div>
            </div>

            <div class="box col-sm-12 anime-right">
                <div class="box__img"><img alt="" src="<?php echo e(image($body->img_icon_3_section1 ?? null)); ?>"/></div>

                <div class="box__cont">
                    <h4><?php echo $body->title_icon_3_section1 ?? null; ?></h4>

                    <p><?php echo $body->title_icon_3_section1 ?? null; ?></p>

                    <div class="lnk-btn more-btn"><a href="#">LEARN MORE</a></div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="col-sm-12">
                <?php
                    $url = $body->link_video_section1 ?? null;
                    parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
                ?>
                <iframe width="100%"
                        <?php echo e($Agent->isMobile() ? '' :'height=550'); ?>  src="https://www.youtube.com/embed/<?php echo e($my_array_of_vars['v'] ?? null); ?>?rel=0"
                        frameborder="0"
                        allow=" autoplay; clipboard-write; encrypted-media; gyroscope"
                        allowfullscreen></iframe>
            </div>
        </div>

    </section>
    <?php $bodyAboutUs = json_decode($about->body) ?>
    <section class="testlab-area text-center bg-full white p100 mt50 valigner"
             style="background-image:url('<?php echo e(image($bodyAboutUs->image_section2 ?? null)); ?>');">
        <div class="container">
            <div class="valign ">
                <h4><?php echo $bodyAboutUs->desc_section2 ?? null; ?></h4>

                <div class="inline-btns mt40">
                    <div class="lnk-btn inline-block def-btn hover"><a href="<?php echo e($bodyAboutUs->link_section2 ?? null); ?>">View Tests</a></div>
                </div>
            </div>
        </div>
    </section>

    <section class="most-area text-center bg-full pt50 pb50">
        <div class="container">
            <div class="most__cont col-sm-7 valigner anime-left">
                <div class="valign">
                    <h3><?php echo $body->title_section2 ?? null; ?></h3>

                    <p><?php echo $body->desc_section2 ?? null; ?></p>

                    <div class="lnk-btn browse-btn"><a href="<?php echo e(route('shop')); ?>">View all Test &gt;&gt;</a></div>
                </div>
            </div>

            <div class="most__img col-sm-5">
                <div class="most__inr box">
                    <div class="most__inr__img hidden"><img alt="" src="/front/images/box1.jpg"/>
                    </div>

                    <div class="most__inr__cont text-center ">
                        <h3>CMP</h3>

                        <p>(Complete Metabolic Panel)</p>
                        <?php if($body->sale_price_section2 != null): ?>
                            <h2><sup><?php echo e(setting('site.currency')); ?></sup><?php echo e($body->sale_price_section2); ?></h2>
                            <strong>Average competitors price</strong>
                            <h4><sup><?php echo e(setting('site.currency')); ?></sup><?php echo e($body->price_section2 ?? null); ?></h4>
                        <?php else: ?>
                            <h2><sup><?php echo e(setting('site.currency')); ?></sup><?php echo e($body->price_section2 ?? null); ?></h2>
                            <strong>Average competitors price</strong>
                        <?php endif; ?>
                        <strong>Pricing based on average direct to consumer pricing.</strong></div>
                </div>
            </div>
        </div>
    </section>

    <section class="most-area text-center pt50 pb50">
        <div class="container">
            <div class="most__cont col-sm-7 valigner anime-right pul-rgt">
                <div class="valign">
                    <h3><?php echo $body->title_section3 ?? null; ?></h3>

                    <p><?php echo $body->desc_section3 ?? null; ?></p>

                    <div class="lnk-btn browse-btn"><a href="<?php echo e(route('how-to-order')); ?>">Let&rsquo;s Get Proactive &gt;&gt;</a>
                    </div>
                </div>
            </div>

            <div class="most__img col-sm-5 pul-lft ">
                <div class="most__inr box">
                    <div class="most__inr__img"><img alt="" src="<?php echo e(image($body->image_section3 ?? null )); ?>"/></div>
                </div>
            </div>
        </div>
    </section>


    <section class="testlab-area text-center bg-full white p100 valigner mt40 rotate-img--hover"
             style="background-image: url('<?php echo e(image($body->image_section4 ?? null )); ?>')">
        <div class="container">
            <div class="valign">
                <h4><i class="fa fa-quote-left" ></i><?php echo $body->title_section4 ?? null; ?><i class="fa fa-quote-right" ></i>
                </h4>
            </div>
        </div>
    </section>
    <?php
        $faqBody = json_decode($faq->body);
    ?>
    <section class="faq-area pb50">
        <div class="container">
            <div class="hed text-center">
                <h2>FAQ</h2>
            </div>
            <div calss="cont">
                <?php echo $faqBody->content_page; ?>

                <div class="panel-group accordion-arr" id="accordion">
                    <div class="col-sm-6 p0">
                        <?php if(!empty($faqBody->detail)): ?>
                            <?php $i = 0; ?>
                            <?php $__currentLoopData = $faqBody->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_left): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse"
                                                                   href="#collapse<?php echo e($i); ?>"><?php echo $detail_left->left_title; ?></a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse collapse " id="collapse<?php echo e($i); ?>">
                                        <div class="panel-body"><?php echo $detail_left->left_content; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-6 p0">
                        <?php if(!empty($faqBody->detail)): ?>
                            <?php $i = 100; ?>
                            <?php $__currentLoopData = $faqBody->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_right): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse"
                                                                   href="#collapse<?php echo e($i); ?>"><?php echo $detail_right->right_title; ?></a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse collapse " id="collapse<?php echo e($i); ?>">
                                        <div class="panel-body"><?php echo $detail_right->right_content; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/newcenturylabs.com/resources/views/front/index.blade.php ENDPATH**/ ?>