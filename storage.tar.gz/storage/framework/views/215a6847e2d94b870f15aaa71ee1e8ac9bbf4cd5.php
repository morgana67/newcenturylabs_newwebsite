<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="ftr__box ftr__links col-sm-4 clrlist listview">
        <h4><?php echo e($menu_item->title); ?></h4>
        <?php if(!$menu_item->children->isEmpty()): ?>
            <ul>
                <?php $__currentLoopData = $menu_item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($children->link()); ?>"><?php echo e($children->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/forge/newcenturylabs.com/resources/views/menu_footer.blade.php ENDPATH**/ ?>