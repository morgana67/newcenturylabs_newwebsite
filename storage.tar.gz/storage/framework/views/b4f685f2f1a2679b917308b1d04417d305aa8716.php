<?php
echo "<title></title><style></style></head><body>" . $body . "</body></html>"
?>
<?php /**PATH /home/forge/newcenturylabs.com/resources/views/emails/template.blade.php ENDPATH**/ ?>